package com.example.qrscanne;

import com.journeyapps.barcodescanner.CaptureActivity;

public class CaptureAct extends CaptureActivity
{
}
